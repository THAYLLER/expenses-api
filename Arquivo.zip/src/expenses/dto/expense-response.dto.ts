import { ApiProperty } from '@nestjs/swagger';
import { ExpenseCategory } from './create-expense.dto';

export class ExpenseResponseDto {
  @ApiProperty({ description: 'ID of the expense' })
  id: string;

  @ApiProperty({ description: 'Description of the expense' })
  description: string;

  @ApiProperty({ description: 'Amount of the expense' })
  amount: number;

  @ApiProperty({
    description: 'Category of the expense',
    enum: ExpenseCategory,
  })
  category: ExpenseCategory;

  @ApiProperty({ description: 'Date of the expense' })
  date: Date;

  @ApiProperty({ description: 'ID of the user who created the expense' })
  userId: string;

  @ApiProperty({ description: 'Creation date of the expense' })
  createdAt: Date;

  @ApiProperty({ description: 'Last update date of the expense' })
  updatedAt: Date;
}
