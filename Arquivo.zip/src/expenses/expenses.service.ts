import {
  Injectable,
  NotFoundException,
  BadRequestException,
} from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { CreateExpenseDto, ExpenseCategory } from './dto/create-expense.dto';
import { UpdateExpenseDto } from './dto/update-expense.dto';
import { Prisma } from '@prisma/client';

@Injectable()
export class ExpensesService {
  constructor(private prisma: PrismaService) {}

  async create(userId: string, createExpenseDto: CreateExpenseDto) {
    if (!Object.values(ExpenseCategory).includes(createExpenseDto.category)) {
      throw new BadRequestException('Categoria inválida');
    }

    const data: Prisma.ExpenseCreateInput = {
      description: createExpenseDto.description,
      amount: createExpenseDto.amount,
      category: createExpenseDto.category,
      date: new Date(createExpenseDto.date),
      user: {
        connect: { id: userId },
      },
    };

    return this.prisma.expense.create({ data });
  }

  async findAll(
    userId: string,
    filters?: {
      category?: string;
      startDate?: string;
      endDate?: string;
    },
  ) {
    const where: Prisma.ExpenseWhereInput = {
      user: { id: userId },
    };

    if (filters?.startDate || filters?.endDate) {
      where.date = {};
      if (filters.startDate) {
        where.date.gte = new Date(filters.startDate);
      }
      if (filters.endDate) {
        where.date.lte = new Date(filters.endDate);
      }
    }

    if (filters?.category) {
      where.category = filters.category;
    }

    return this.prisma.expense.findMany({
      where,
      orderBy: {
        date: 'desc',
      },
    });
  }

  async findOne(userId: string, id: string) {
    const expense = await this.prisma.expense.findFirst({
      where: {
        id,
        user: { id: userId },
      },
    });

    if (!expense) {
      throw new NotFoundException('Expense not found');
    }

    return expense;
  }

  async update(userId: string, id: string, updateExpenseDto: UpdateExpenseDto) {
    const expense = await this.findOne(userId, id);

    return this.prisma.expense.update({
      where: { id: expense.id },
      data: {
        ...updateExpenseDto,
        date: updateExpenseDto.date
          ? new Date(updateExpenseDto.date)
          : undefined,
      },
    });
  }

  async remove(userId: string, id: string) {
    const expense = await this.findOne(userId, id);
    return this.prisma.expense.delete({ where: { id: expense.id } });
  }
}
