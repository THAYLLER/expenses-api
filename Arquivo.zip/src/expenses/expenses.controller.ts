import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
  UseGuards,
  Query,
  ParseUUIDPipe,
  Request,
} from '@nestjs/common';
import { ExpensesService } from './expenses.service';
import { CreateExpenseDto } from './dto/create-expense.dto';
import { UpdateExpenseDto } from './dto/update-expense.dto';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { ApiTags, ApiOperation, ApiResponse, ApiBearerAuth, ApiQuery, ApiParam, ApiCreatedResponse, ApiOkResponse, ApiNotFoundResponse, ApiBadRequestResponse, ApiUnauthorizedResponse } from '@nestjs/swagger';

@ApiTags('expenses')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller('expenses')
export class ExpensesController {
  constructor(private readonly expensesService: ExpensesService) {}

  @Post()
  @ApiOperation({ 
    summary: 'Criar uma nova despesa',
    description: 'Cria uma nova despesa para o usuário autenticado'
  })
  @ApiCreatedResponse({
    description: 'Despesa criada com sucesso',
    type: CreateExpenseDto
  })
  @ApiBadRequestResponse({
    description: 'Dados inválidos',
    schema: {
      type: 'object',
      properties: {
        statusCode: { type: 'number', example: 400 },
        message: { type: 'array', items: { type: 'string' }, example: ['Valor deve ser maior que zero'] },
        error: { type: 'string', example: 'Bad Request' }
      }
    }
  })
  @ApiUnauthorizedResponse({
    description: 'Não autorizado',
    schema: {
      type: 'object',
      properties: {
        statusCode: { type: 'number', example: 401 },
        message: { type: 'string', example: 'Não autorizado' },
        error: { type: 'string', example: 'Unauthorized' }
      }
    }
  })
  @ApiResponse({ status: 201, description: 'Created' })
  create(@Body() createExpenseDto: CreateExpenseDto, @Request() req) {
    return this.expensesService.create(req.user.id, createExpenseDto);
  }

  @Get()
  @ApiOperation({ 
    summary: 'Listar todas as despesas do usuário',
    description: 'Retorna todas as despesas do usuário autenticado, com opção de filtros'
  })
  @ApiQuery({
    name: 'startDate',
    required: false,
    type: String,
    description: 'Data inicial no formato YYYY-MM-DD',
    example: '2024-01-01'
  })
  @ApiQuery({
    name: 'endDate',
    required: false,
    type: String,
    description: 'Data final no formato YYYY-MM-DD',
    example: '2024-12-31'
  })
  @ApiQuery({
    name: 'category',
    required: false,
    type: String,
    description: 'Categoria da despesa',
    enum: ['FOOD', 'TRANSPORT', 'HOUSING', 'UTILITIES', 'ENTERTAINMENT', 'HEALTH', 'EDUCATION', 'SHOPPING', 'TRAVEL', 'OTHER'],
    example: 'FOOD'
  })
  @ApiOkResponse({
    description: 'Lista de despesas retornada com sucesso',
    type: [CreateExpenseDto]
  })
  @ApiUnauthorizedResponse({
    description: 'Não autorizado',
    schema: {
      type: 'object',
      properties: {
        statusCode: { type: 'number', example: 401 },
        message: { type: 'string', example: 'Não autorizado' },
        error: { type: 'string', example: 'Unauthorized' }
      }
    }
  })
  @ApiResponse({ status: 200, description: 'OK' })
  findAll(
    @Request() req,
    @Query('startDate') startDate?: string,
    @Query('endDate') endDate?: string,
    @Query('category') category?: string,
  ) {
    return this.expensesService.findAll(req.user.id, {
      category,
      startDate,
      endDate,
    });
  }

  @Get(':id')
  @ApiOperation({ 
    summary: 'Buscar uma despesa específica',
    description: 'Retorna os detalhes de uma despesa específica do usuário autenticado'
  })
  @ApiParam({
    name: 'id',
    description: 'ID da despesa (UUID)',
    type: 'string',
    format: 'uuid',
    example: '123e4567-e89b-12d3-a456-426614174000'
  })
  @ApiOkResponse({
    description: 'Despesa encontrada com sucesso',
    type: CreateExpenseDto
  })
  @ApiNotFoundResponse({
    description: 'Despesa não encontrada',
    schema: {
      type: 'object',
      properties: {
        statusCode: { type: 'number', example: 404 },
        message: { type: 'string', example: 'Despesa não encontrada' },
        error: { type: 'string', example: 'Not Found' }
      }
    }
  })
  @ApiUnauthorizedResponse({
    description: 'Não autorizado',
    schema: {
      type: 'object',
      properties: {
        statusCode: { type: 'number', example: 401 },
        message: { type: 'string', example: 'Não autorizado' },
        error: { type: 'string', example: 'Unauthorized' }
      }
    }
  })
  @ApiResponse({ status: 200, description: 'OK' })
  findOne(@Param('id', ParseUUIDPipe) id: string, @Request() req) {
    return this.expensesService.findOne(req.user.id, id);
  }

  @Patch(':id')
  @ApiOperation({ 
    summary: 'Atualizar uma despesa',
    description: 'Atualiza os dados de uma despesa específica do usuário autenticado'
  })
  @ApiParam({
    name: 'id',
    description: 'ID da despesa (UUID)',
    type: 'string',
    format: 'uuid',
    example: '123e4567-e89b-12d3-a456-426614174000'
  })
  @ApiOkResponse({
    description: 'Despesa atualizada com sucesso',
    type: CreateExpenseDto
  })
  @ApiBadRequestResponse({
    description: 'Dados inválidos',
    schema: {
      type: 'object',
      properties: {
        statusCode: { type: 'number', example: 400 },
        message: { type: 'array', items: { type: 'string' }, example: ['Valor deve ser maior que zero'] },
        error: { type: 'string', example: 'Bad Request' }
      }
    }
  })
  @ApiNotFoundResponse({
    description: 'Despesa não encontrada',
    schema: {
      type: 'object',
      properties: {
        statusCode: { type: 'number', example: 404 },
        message: { type: 'string', example: 'Despesa não encontrada' },
        error: { type: 'string', example: 'Not Found' }
      }
    }
  })
  @ApiUnauthorizedResponse({
    description: 'Não autorizado',
    schema: {
      type: 'object',
      properties: {
        statusCode: { type: 'number', example: 401 },
        message: { type: 'string', example: 'Não autorizado' },
        error: { type: 'string', example: 'Unauthorized' }
      }
    }
  })
  @ApiResponse({ status: 200, description: 'OK' })
  update(
    @Param('id', ParseUUIDPipe) id: string,
    @Body() updateExpenseDto: UpdateExpenseDto,
    @Request() req,
  ) {
    return this.expensesService.update(req.user.id, id, updateExpenseDto);
  }

  @Delete(':id')
  @ApiOperation({ 
    summary: 'Remover uma despesa',
    description: 'Remove uma despesa específica do usuário autenticado'
  })
  @ApiParam({
    name: 'id',
    description: 'ID da despesa (UUID)',
    type: 'string',
    format: 'uuid',
    example: '123e4567-e89b-12d3-a456-426614174000'
  })
  @ApiOkResponse({
    description: 'Despesa removida com sucesso',
    schema: {
      type: 'object',
      properties: {
        message: { type: 'string', example: 'Despesa removida com sucesso' }
      }
    }
  })
  @ApiNotFoundResponse({
    description: 'Despesa não encontrada',
    schema: {
      type: 'object',
      properties: {
        statusCode: { type: 'number', example: 404 },
        message: { type: 'string', example: 'Despesa não encontrada' },
        error: { type: 'string', example: 'Not Found' }
      }
    }
  })
  @ApiUnauthorizedResponse({
    description: 'Não autorizado',
    schema: {
      type: 'object',
      properties: {
        statusCode: { type: 'number', example: 401 },
        message: { type: 'string', example: 'Não autorizado' },
        error: { type: 'string', example: 'Unauthorized' }
      }
    }
  })
  @ApiResponse({ status: 200, description: 'OK' })
  remove(@Param('id', ParseUUIDPipe) id: string, @Request() req) {
    return this.expensesService.remove(req.user.id, id);
  }
}
