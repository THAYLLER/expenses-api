import { ApiProperty } from '@nestjs/swagger';

export class FilterResponseDto {
  @ApiProperty({ description: 'Field being filtered' })
  field: string;

  @ApiProperty({ description: 'Filter operator' })
  operator: string;

  @ApiProperty({ description: 'Filter value' })
  value: any;
}
