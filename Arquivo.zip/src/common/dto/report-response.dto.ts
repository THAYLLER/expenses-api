import { ApiProperty } from '@nestjs/swagger';

export class ReportResponseDto {
  @ApiProperty({ description: 'Report ID' })
  id: string;

  @ApiProperty({ description: 'Report name' })
  name: string;

  @ApiProperty({ description: 'Report description' })
  description: string;

  @ApiProperty({ description: 'Report type' })
  type: string;

  @ApiProperty({ description: 'Report parameters' })
  parameters: Record<string, any>;

  @ApiProperty({ description: 'Report result' })
  result: any;

  @ApiProperty({ description: 'User ID who created the report' })
  userId: string;

  @ApiProperty({ description: 'Report creation date' })
  createdAt: Date;

  @ApiProperty({ description: 'Report last update date' })
  updatedAt: Date;
}
