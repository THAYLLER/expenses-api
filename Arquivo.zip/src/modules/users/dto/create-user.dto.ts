import { z } from 'zod';
import { createZodDto } from '@anatine/zod-nestjs';

export const CreateUserSchema = z.object({
  email: z.string().email(),
  password: z.string().min(6),
});

export class CreateUserDto extends createZodDto(CreateUserSchema) {}
