import { Controller } from '@nestjs/common';

@Controller('expenses')
export class ExpensesController {}
