import {
  Injectable,
  ExecutionContext,
  UnauthorizedException,
  Logger,
} from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';

@Injectable()
export class JwtAuthGuard extends AuthGuard('jwt') {
  private readonly logger = new Logger(JwtAuthGuard.name);

  canActivate(context: ExecutionContext) {
    const request = context.switchToHttp().getRequest();
    const authHeader = request.headers.authorization;

    if (!authHeader) {
      this.logger.error('No auth token');
      throw new UnauthorizedException('No auth token');
    }

    if (!authHeader.startsWith('Bearer ')) {
      this.logger.error('Invalid token format');
      throw new UnauthorizedException('Invalid token format');
    }

    this.logger.debug(`Validating request to: ${request.url}`);
    return super.canActivate(context);
  }

  handleRequest(err: any, user: any, info: any) {
    if (err) {
      this.logger.error(`JWT validation error: ${err.message}`);
      throw new UnauthorizedException(err.message);
    }

    if (!user) {
      this.logger.error(
        `JWT validation failed: ${info?.message || 'No user found'}`,
      );
      throw new UnauthorizedException(info?.message || 'No user found');
    }

    return user;
  }
}
